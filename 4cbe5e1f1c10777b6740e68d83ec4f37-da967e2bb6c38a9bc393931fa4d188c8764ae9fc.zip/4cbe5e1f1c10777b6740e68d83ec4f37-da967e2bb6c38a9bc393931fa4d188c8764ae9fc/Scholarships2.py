import pandas as pd


def main():
    data = pd.read_csv(r"C:\Users\phurl\Downloads\scholarships (1).csv")
    df = pd.DataFrame(data)
    input = collect_student_info()
    df=numSort(df,input['gpa'],'GPA')
    df=numSort(df,input['sat-score'],'SAT')
    df=numSort(df,input['act-score'],'ACT')
    df["scholarship_score"] = round((df["Scholarship Award"] / df["Number applied"]), 2)
    sorted_df= df.sort_values(by="scholarship_score", ascending=False)
    print(sorted_df.head(3))
def collect_student_info():
    student_info = {}

    print("Please input your information")
    student_info['gpa'] = float(input("GPA (X.X): "))
    student_info['act-score'] = int(input("ACT Score (Enter 0 if not taken): "))
    student_info['sat-score'] = int(input("SAT score (Enter 0 if not taken): "))
    student_info['ethnicity'] = int(input("Ethnicty: 1.White 2.Black 3.Asian 4.Hispanic 5.Native-American 6.Other Please enter a number: "))
    student_info['study'] = int(input("Plan of Study: 1.ENGR 2.LAW 3.MED 4.BUAD 5.NURSE Please enter a number: "))
    student_info['State'] = input("Please enter your state abbreviation: ").upper()
    student_info['school'] = input('Please enter your university: ').lower()
    student_info['first-gen'] = input('Are you first generation (Y/N): ').upper()
    return student_info


def merge(arr, l, m, r):
    n1 = m - l + 1
    n2 = r - m
    L = [0] * (n1)
    R = [0] * (n2)
    for i in range(0, n1):
        L[i] = arr[l + i]
    for j in range(0, n2):
        R[j] = arr[m + 1 + j]
    i = 0
    j = 0
    k = l
    while i < n1 and j < n2:
        if L[i] <= R[j]:
            arr[k] = L[i]
            i += 1
        else:
            arr[k] = R[j]
            j += 1
        k += 1
    while i < n1:
        arr[k] = L[i]
        i += 1
        k += 1
    while j < n2:
        arr[k] = R[j]
        j += 1
        k += 1

def insertionSort(arr):
    n = len(arr)
    if n <= 1:
        return
    for i in range(1, n):
        key = arr[i]
        j = i - 1
        while j >= 0 and key < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key


def mergeSort(s_list, low, high):
    if ((high - low) < 50):
        insertionSort(s_list)
    else:
        if low < high:
            mid = low + (high-low) // 2
            mergeSort(s_list, low, mid)
            mergeSort(s_list, mid + 1, high)
            merge(s_list, low, mid, high)

def numSort(df, inputVal, var):
    arr=df.to_numpy()
    length = len(arr)
    list = [0 for y in range(length)]
    if(var=='GPA'):
        for x in range(0,length):
            list[x]=arr[x][4]
    if(var=='SAT'):
        if inputVal==0:
            return df
        for x in range(0,length):
            list[x]=arr[x][3]
    if(var=='ACT'):
        if inputVal==0:
            return df
        for x in range(0,length):
            list[x]=arr[x][2]
    mergeSort(list, 0, length-1)
    count=0
    y=0
    if inputVal>=list[length-1]:
        return df
    while(list[y]<=inputVal):
        count+=1
        y+=1
    df.sort_values(by=var,ascending=False)
    return df.iloc[(length-count)+1:length-1]

def binary_serch(data,target,var):
    left, right = 0,  len(data) -1
    data.sort_values(by='Study', inplace=True)

    while left <= right:
        mid = (left + right) // 2
        mid_value = str(data.iloc[mid][var])
        #print(mid_value)
        #print(target)
        if mid_value == str(target):
            data.append(data.iloc[mid]['Scholarship Name'])
            left_match, right_match = mid -1, mid +1
           # print("hello")
            while left_match >= 0 and str(data.iloc[left_match][var]) == target:
                data.append(data.iloc[left_match]['Scholarship Name'])
                left_match -=1
            while right_match < len(data) and str(data.iloc[right_match][var]):
                data.append(data.iloc[right_match]['Scholarship Name'])
                right_match += 1
            #print(matches)
            return data

            #return mid
        elif mid_value < str(target):
            left = mid+1
        else:
            right = mid -1

    #returns -1 if not found
    return data




main()
